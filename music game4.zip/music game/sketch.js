//////////前奏300
var a1 = -200;
var a1c = -200;
var a2 = -500;
var a2c = -500;
var a3 = -800;
var a3c = -800;
var a4 = -1100;
var a4c = -1100;
var a5 = -1400;
var a5c = -1400;
var a6 = -1700;
var a6c = -1700;
var a7 = -2000;
var a7c = -2000;
var a8 = -2300;
var a8c = -2300;
var a9 = -2600;
var a9c = -2600;
var a10 = -2900;
var a10c = -2900;
var a11 = -3200;
var a11c = -3200;
var a12 = -3500;
var a12c = -3500;
var a13 = -3800;
var a13c = -3800;
var a14 = -4100;
var a14c = -4100;
var a15 = -4400;
var a15c = -4400;
var a16 = -4700;
var a16c = -4700;
var a17 = -5000;
var a17c = -5000;
var a18 = -5300;
var a18c = -5300;
var a19 = -5600;
var a19c = -5600;
var a20 = -5900;
var a20c = -5900;
var a21 = -6200;
var a21c = -6200;
var a22 = -6500;
var a22c = -6500;
var a23 = -6800;
var a23c = -6800;
var a24 = -7100;
var a24c = -7100;
var a25 = -7400;
var a25c = -7400;
var a26 = -7700;
var a26c = -7700;
var a27 = -8000;
var a27c = -8000;
var a28 = -8300;
var a28c = -8300;
var a29 = -8600;
var a29c = -8600;
var a30 = -8900;
var a30c = -8900;
var a31 = -9200;
var a31c = -9200;
var a32 = -9500;
var a32c = -9500;
var a33 = -9800;
var a33c = -9800;
var a34 = -10100;
var a34c = -10100;
var a35 = -10400;
var a35c = -10400;
var a36 = -10700;
var a36c = -10700;
var a37 = -11000;
var a37c = -11000;
var a38 = -11300;
var a38c = -11300;
var a39 = -11600;
var a39c = -11600;
var a40 = -11900;
var a40c = -11900;
var a41 = -12200;
var a41c = -12200;
var a42 = -12500;
var a42c = -12500;
var a43 = -12800;
var a43c = -12800;
var a44 = -13100;
var a44c = -13100;
var a45 = -13400;
var a45c = -13400;
var a46 = -13700;
var a46c = -13700;
var a47 = -14000;
var a47c = -14000;
var a48 = -14080;
var a48c = -14080;
var a49 = -14240;
var a49c = -14240;
var a50 = -14360;
var a50c = -14360;
var a51 = -14500;
var a51c = -14500;
var a52 = -14640;
var a52c = -14640;
var a53 = -14780;
var a53c = -14780;
var a54 = -14920;
var a54c = -14920;
var a55 = -15100;
var a55c = -15100;
var a56 = -15240;
var a56c = -15240;
var a57 = -15460;
var a57c = -15460;
var a58 = -15600;
var a58c = -15600;
//////////
//////////副歌130
var a59 = -15800;
var a59c = -15800;
var a60 = -15930;
var a60c = -15930;
var a61 = -16060;
var a61c = -16060;
var a62 = -16190;
var a62c = -16190;
var a63 = -16320;
var a63c = -16320;
var a64 = -16440;
var a64c = -16440;
var a65 = -16570;
var a65c = -16570;
var a66 = -16700;
var a66c = -16700;
var a67 = -16830;
var a67c = -16830;
var a68 = -16960;
var a68c = -16960;
var a69 = -17060;
var a69c = -17060;
var a70 = -17190;
var a70c = -17190;
var a71 = -17320;
var a71c = -17320;
var a72 = -17450;
var a72c = -17450;
var a73 = -17580;
var a73c = -17580;
var a74 = -17710;
var a74c = -17710;
var a75 = -17850;
var a75c = -17850;
var a76 = -17980;
var a76c = -17980;
var a77 = -18110;
var a77c = -18110;
var a78 = -18240;
var a78c = -18240;
var a79 = -18370;
var a79c = -18370;
var a80 = -18500;
var a80c = -18500;
var a81 = -18630;
var a81c = -18630;
var a82 = -18760;
var a82c = -18890;
var a83 = -19020;
var a83c = -19020;
var a84 = -19150;
var a84c = -19150;
var a85 = -19280;
var a85c = -19280;
var a86 = -19410;
var a86c = -19410;
var a87 = -19540;
var a87c = -19540;
var a88 = -19670;
var a88c = -19670;
var a89 = -19800;
var a89c = -19800;
var a90 = -19930;
var a90c = -19930
var a91 = -20060;
var a91c = -20060;
var a92 = -20190;
var a92c = -20190;
var a93 = -20320;
var a93c = -20320;
var a94 = -20450;
var a94c = -20450;
var a95 = -20580;
var a95c = -20580;
var a96 = -20710;
var a96c = -20710;
var a97 = -20840;
var a97c = -20840;
var a98 = -20970;
var a98c = -20970;
var a99 = -20970;
var a99c = -20970;
var a100 = -21100;
var a100c = -21100;
var a101 = -21230;
var a101c = -21230;
var a102 = -21360;
var a102c = -21360;
var a103 = -21490;
var a103c = -21490;
var a104 = -21620;
var a104c = -21620;
var a105 = -21750;
var a105c = -21750;
var a106 = -21900;
var a106c = -21900;
var a107 = -22030;
var a107c = -22030;
var a108 = -22260;
var a108c = -22260;
var a109 = -22260;
var a109c = -22260;
var a110 = -22320;
var a110c =- 22320;
var a111 = -22420;
var a111c = -22420;
var a112 = -22550;
var a112c = -22550;
var a113 = -22680;
var a113c = -22680;
var a114 = -22810;
var a114c = -22810;
var a115 = -22940;
var a115c = -22940;
var a116 = -23070;
var a116c = -23070;
var a117 = -23200;
var a117c = -23200;
var a118 = -23330;
var a118c = -23330;
var a119 = -23460;
var a119c = -23460;
var a120 = -23460;
var a120c = -23460;
var a121 = -23810;
var a121c = -23810;
var a122 = -24160;
var a122c = -24160;
var a123 = -24460;
var a123c = -24460;
var a124 = -24460;
var a124c = -24460;
var a125 = -24610;
var a125c = -24610;
var a126 = -24760;
var a126c = -24760;
//////////
////////// 快打65
var a127 = -25260;
var a127c = -25260;
var a128 = -25260;
var a128c = -25260;

var a129 = -25390;
var a129c = -25390;
var a130 = -25390;
var a130c = -25390;

var a131 = -25520;
var a131c = -25520;
var a132 = -25520;
var a132c = -25520;

var a133 = -25650;
var a133c = -25650;
var a134 = -25650;
var a134c = -25650;

var a135 = -25780;
var a135c = -25780;
var a136 = -25780;
var a136c = -25780;

var a137 = -25910;
var a137c = -25910;
var a138 = -25910;
var a138c = -25910;
//////////
//////////進副歌(重)150
var a139 = -26130;
var a139c = -26130;
var a140 = -26280;
var a140c = -26280;
var a141 = -26430;
var a141c = -26430;
var a142 = -26580;
var a142c = -26580;
var a143 = -26750;
var a143c = -26750;
var a144 = -26900;
var a144c = -26900;
var a145 = -27050;
var a145c = -27050;
var a146 = -27200;
var a146c = -27200;
//////////副歌(重)170||160
var a147 = -27410;
var a147c = -27410;
var a148 = -27580;
var a148c = -27580;
var a149 = -27750;
var a149c = -27750;
var a150 = -27920;
var a150c = -27920;
var a151 = -28070;
var a151c = -28070;
var a152 = -28240;
var a152c = -28240;
var a153 = -28410;
var a153c = -28410;
var a154 = -28580;
var a154c = -28580;
var a155 = -28750;
var a155c = -28750;
var a156 = -28920;
var a156c = -28920;
var a157 = -29090;
var a157c = -29090;
var a158 = -29260;
var a158c = -29260;
var a159 = -29430;
var a159c = -29430;
var a160 = -29570;
var a160c = -29570;
var a161 = -29720;
var a161c = -29720;
var a162 = -29890;
var a162c = -29890;
var a163 = -30050;
var a163c = -30050;
var a164 = -30200;
var a164c = -30200;
var a165 = -30360;
var a165c = -30360;
var a166 = -30500;
var a166c = -30500;
var a167 = -30670;
var a167c = -30670;
var a168 = -30880;
var a168c = -30880;
var a169 = -31050;
var a169c = -31050;
var a170 = -31210;
var a170c = -31210;
var a171 = -31350;
var a171c = -31350;
var a172 = -31580;
var a172c = -31580;
var a173 = -31720;
var a173c = -31720;
var a174 = -31890;
var a174c = -31890;
var a175 = -32060;
var a175c = -32060;
var a176 = -32230; 
var a176c = -32230;
var a177 = -32410;
var a177c = -32410;
var a178 = -32570;
var a178c = -32570;
var a179 = -32730;
var a179c = -32730;
var a180 = -32900;
var a180c = -32900;
var a181 = -33080;
var a181c = -33080;
var a182 = -33240;
var a182c = -33240;
var a183 = -33400;
var a183c = -33400;
var a184 = -33560;
var a184c = -33560;
var a185 = -33720;
var a185c = -33720;
var a186 = -33880;
var a186c = -33880;
var a187 = -34040;
var a187c = -34040;
var a188 = -34200;
var a188c = -34200;
var a189 = -34360;
var a189c = -34360;
var a190 = -34520;
var a190c = -34520;
var a191 = -34680;
var a191c = -34680;
var a192 = -34840;
var a192c = -34840;
var a193 = -35000;
var a193c = -35000;
var a194 = -35160;
var a194c = -35160;
var a195 = -35320;
var a195c = -35320;
var a196 = -35480;
var a196c = -35480;
var a197 = -35640;
var a197c = -35640;
var a198 = -35800;
var a198c = -35800;
var a199 = -35960;
var a199c = -35960;
var a200 = -36120;
var a200c = -36120
var a201 = -36300;
var a201c = -36300;
var a202 = -36460;
var a202c = -36460
/////////進副歌(快)70
var a203 = -36530;
var a203c = -36530;
var a204 = -36600;
var a204c = -36600;
var a205 = -36670;
var a205c = -36670;
var a206 = -36730;
var a206c = -36730;
var a207 = -36790;
var a207c = -36790;
var a208 = -36860;
var a208c = -36860;
var a209 = -36930;
var a209c = -36930;
var a210 = -37000;
var a210c = -37000;
var a211 = -37070;
var a211c = -37070;
var a212 = -37140;
var a212c = -37140;
var a213 = -37210;
var a213c = -37210;
var a214 = -37280;
var a214c = -37280;
var a215 = -37350;
var a215c = -37350;
var a216 = -37420;
var a216c = -37420;
var a217 = -37490;
var a217c = -37490;
var a218 = -37560;
var a218c = -37560;
//////////副歌(快)100
var a219 = -37660;
var a219c = -37660;
var a220 = -37760;
var a220c = -37760;
var a221 = -37860;
var a221c = -37860;
var a222 = -37960;
var a222c = -37960;
var a223 = -38060;
var a223c = -38060;
var a224 = -38160;
var a224c = -38160;
var a225 = -38260;
var a225c = -38260;
var a226 = -38360;
var a226c = -38360;
var a227 = -38460;
var a227c = -38460;
var a228 = -38560;
var a228c = -38560;
var a229 = -38660;
var a229c = -38660;
var a230 = -38760;
var a230c = -38760;
var a231 = -38860;
var a231c = -38860;
var a232 = -38960;
var a232c = -38960;
var a233 = -39060;
var a233c = -39060;
var a234 = -39160;
var a234c = -39160;
var a235 = -39260;
var a235c = -39260;
var a236 = -39360;
var a236c = -39360;
var a237 = -39460;
var a237c = -39460;
var a238 = -39560;
var a238c = -39560;
var a239 = -39660;
var a239c = -39660;
var a240 = -39760;
var a240c = -39760;
var a241 = -39860;
var a241c = -39860;
var a242 = -39960;
var a242c = -39960;
var a243 = -40060;
var a243c = -40060;
var a244 = -40160;
var a244c = -40160;
var a245 = -40260;
var a245c = -40260;
var a246 = -40360;
var a246c = -40360;
var a247 = -40460;
var a247c = -40460;
var a248 = -40560;
var a248c = -40560;
var a249 = -40660;
var a249c = -40660;
var a250 = -40760;
var a250c = -40760;
var a251 = -40860;
var a251c = -40860;
var a252 = -40960;
var a252c = -40960;
var a253 = -41060;
var a253c = -41060;
var a254 = -41160;
var a254c = -41160;
var a255 = -41260;
var a255c = -41260;
var a256 = -41360;
var a256c = -41360;
var a257 = -41460;
var a257c = -41460;
var a258 = -41560;
var a258c = -41560;
var a259 = -41660;
var a259c = -41660;
var a260 = -41760;
var a260c = -41760;
var a261 = -41860;
var a261c = -41860;
var a262 = -41960;
var a262c = -41960;
var a263 = -42060;
var a263c = -42060;
var a264 = -42160;
var a264c = -42160;
var a265 = -42260;
var a265c = -42260;
var a266 = -42430;
var a266c = -42430;
var a267 = -42590;
var a267c = -42590;
var a268 = -42720;
var a268c = -42720;
var a269 = -42850;
var a269c = -42850;
var a270 = -42930;
var a270c = -42930;
var a271 = -43030;
var a271c = -43030;
var a272 = -43130;
var a272c = -43130;
var a273 = -43230;
var a273c = -43230;
var a274 = -43330;
var a274c = -43330;
var a275 = -43430;
var a275c = -43430;
var a276 = -43530;
var a276c = -43530;
var a277 = -43630;
var a277c = -43630;
var a278 = -43730;
var a278c = -43730;
var a279 = -43830;
var a279c = -43830;
var a280 = -43930;
var a280c = -43930;
var a281 = -44030;
var a281c = -44030;
var a282 = -44130;
var a282c = -44130;
var a283 = -44230;
var a283c = -44230;
var a284 = -44330;
var a284c = -44330;
var a285 = -44430;
var a285c = -44430;
var a286 = -44530;
var a286c = -44530;
var a287 = -44630;
var a287c = -44630;
var a288 = -44730;
var a288c = -44730;
var a289 = -44830;
var a289c = -44830;
var a290 = -44930;
var a290c = -44930;
var a291 = -45030;
var a291c = -45030
var a292 = -45130;
var a292c = -45130;
var a293 = -45230;
var a293c = -45230;
var a294 = -45330;
var a294c = -45330;
var a295 = -45430;
var a295c = -45430;
var a296 = -45530;
var a296c = -45530;
var a297 = -45630;
var a297c = -45630;
var a298 = -45730;
var a298c = -45730;
var a299 = -45830;
var a299c = -45830;
var a300 = -45930
var a300c = -45930;
var a301 = -46030;
var a301c = -46030;
var a302 = -46130;
var a302c = -46130;
var a303 = -46230;
var a303c = -46230;
var a304 = -46330;
var a304c = -46330;
var a305 = -46430;
var a305c = -46430;
var a306 = -46530;
var a306c = -46530;
var a307 = -46630;
var a307c = -46630;
var a308 = -46730;
var a308c = -46730;
var a309 = -46830;
var a309c = -46830;
var a310 = -46930;
var a310c = -46930;
var a311 = -47030;
var a311c = -47030;
var a312 = -47130;
var a312c = -47130;
var a313 = -47230;
var a313c = -47230;
var a314 = -47330;
var a314c = -47330;
var a315 = -47430;
var a315c = -47430;
var a316 = -47530;
var a316c = -47530;
var a317 = -47630;
var a317c = -47630;
var a318 = -47730;
var a318c = -47730;
var a319 = -47830;
var a319c = -47830;
var a320 = -47930;
var a320c = -47930;
//////////最後前120
var a321 = -48000;
var a321c = -48000;
var a322 = -48120;
var a322c = -48120;
var a323 = -48240;
var a323c = -48240;
var a324 = -48360;
var a324c = -48360;
var a325 = -48480;
var a325c = -48480;
var a326 = -48600;
var a326c = -48600;
var a327 = -48720;
var a327c = -48720;
var a328 = -48840;
var a328c = -48840;
var a329 = -48960;
var a329c = -48960;
var a330 = -49080;
var a330c = -49080;
var a331 = -49200;
var a331c = -49200;
var a332 = -49320;
var a332c = -49320;
var a333 = -49440;
var a333c = -49440;
var a334 = -49560;
var a334c = -49560;
var a335 = -49680;
var a335c = -49680;
var a336 = -49800;
var a336c = -49800;
var a337 = -49920;
var a337c = -49920;
var a338 = -50040;
var a338c = -50040;
var a339 = -50160;
var a339c = -50160;
var a340 = -50280;
var a340c = -50280;
var a341 = -50400;
var a341c = -50400;
var a342 = -50520;
var a342c = -50520;
var a343 = -50640;
var a343c = -50640;
var a344 = -50760;
var a344c = -50760;
var a345 = -50880;
var a345c = -50880;
var a346 = -51000;
var a346c = -51000;
var a347 = -51120;
var a347c = -51120;
var a348 = -51240;
var a348c = -51240;
var a349 = -51360;
var a349c = -51360
var a350 = -51480;
var a350c = -51480;
var a351 = -51600;
var a351c = -51600;
var a352 = -51720;
var a352c = -51720;
var a353 = -51840;
var a353c = -51840; 
var a354 = -51960;
var a354c = -51960;
var a355 = -52080;
var a355c = -52080;
var a356 = -52200;
var a356c = -52200;
var a357 = -52320;
var a357c = -52320;
var a358 = -52440;
var a358c = -52440;
var a359 = -52560;
var a359c = -52560;
var a360 = -52680;
var a360c = -52680;
//////////進副歌(重)160
var a361 = -52750;
var a361c = -52750;
var a362 = -52910;
var a362c = -52910;
var a363 = -53070;
var a363c = -53070;
var a364 = -53230;
var a364c = -53230;
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a
var a

var z = 0;
var e = 0;
var sp = 10;
var sc = 0;
var start = [];
var s;
var song;
var press = [];
var com = 0;
var wei;
var weia;
var sec;
function preload()
{
  s = loadImage('square.jpg');
}
function setup()
{
  createCanvas(800,700);
  smooth();
  background(200);
  start[0] = false; 
}
function draw()
{
  //image(s,100,a129-130,100,150);
  //image(s,200,a130-130,100,150);
    if(start[0])
  {
    fill(0);
    textSize(50);
    text(com,180,350);
    song.autoplay(true);
    song.volume(0.05);
    //////////前奏
    //a1 = pressed('d',0,a1,a1c);
    //a2 = stpressed(1,100,a2,2,a2c);
    a1 = pressed('d',0,a1,a1c);
    a2 = pressed('k',300,a2,a2c);
    a3 = pressed('f',100,a3,a3c);
    a4 = pressed('j',200,a4,a4c);
    a5 = pressed('d',0,a5,a5c);
    a6 = pressed('f',100,a6,a6c);
    a7 = pressed('k',300,a7,a7c);
    a8 = pressed('j',200,a8,a8c);
    a9 = pressed('d',0,a9,a9c);
    a10 = pressed('k',300,a10,a10c);
    a11 = pressed('f',100,a11,a11c);
    a12 = pressed('j',200,a12,a12c);
    a13 = pressed('k',300,a13,a13c);
    a14 = pressed('d',0,a14,a14c);
    a15 = pressed('f',100,a15,a15c);
    a16 = pressed('j',200,a16,a16c);
    a17 = pressed('f',100,a17,a17c);
    a18 = pressed('k',300,a18,a18c);
    a19 = pressed('d',0,a19,a19c);
    a20 = pressed('j',200,a20,a20c);
    a21 = pressed('d',0,a21,a21c);
    a22 = pressed('k',300,a22,a22c);
    a23 = pressed('f',100,a23,a23c);
    a24 = pressed('j',200,a24,a24c);
    a25 = pressed('d',0,a25,a25c);
    a26 = pressed('f',100,a26,a26c);
    a27 = pressed('k',300,a27,a27c);
    a28 = pressed('j',200,a28,a28c);
    a29 = pressed('d',0,a29,a29c);
    a30 = pressed('k',300,a30,a30c);
    a31 = pressed('f',100,a31,a31c);
    a32 = pressed('j',200,a32,a32c);
    a33 = pressed('k',300,a33,a33c);
    a34 = pressed('d',0,a34,a34c);
    a35 = pressed('f',100,a35,a35c);
    a36 = pressed('j',200,a36,a36c);
    a37 = pressed('f',100,a37,a37c);
    a38 = pressed('k',300,a38,a38c);
    a39 = pressed('d',0,a39,a39c);
    a40 = pressed('j',200,a40,a40c);
    a41 = pressed('d',0,a41,a41c);
    a42 = pressed('k',300,a42,a42c);
    a43 = pressed('f',100,a43,a43c);
    a44 = pressed('j',200,a44,a44c);
    a45 = pressed('d',0,a45,a45c);
    a46 = pressed('f',100,a46,a46c);
    a47 = pressed('k',300,a47,a47c);
    a48 = pressed('j',200,a48,a48c);
    a49 = pressed('f',100,a49,a49c);
    a50 = pressed('d',0,a50,a50c);
    a51 = pressed('k',300,a51,a51c);
    a52 = pressed('j',200,a52,a52c);
    a53 = pressed('f',100,a53,a53c);
    a54 = pressed('d',0,a54,a54c);
    a55 = pressed('d',0,a55,a55c);
    a56 = pressed('f',100,a56,a56c);
    a57 = pressed('j',200,a57,a57c);
    a58 = pressed('k',300,a58,a58c);
    //////////
    //////////副歌
    a59 = pressed('d',0,a59,a59c);
    a60 = pressed('k',300,a60,a60c);
    a61 = pressed('j',200,a61,a61c);
    a62 = pressed('f',100,a62,a62c);
    a63 = pressed('j',200,a63,a63c);
    a64 = pressed('d',0,a64,a64c);
    a65 = pressed('k',300,a65,a65c);
    a66 = pressed('f',100,a66,a66c);
    a67 = pressed('j',200,a67,a67c);
    a68 = pressed('k',300,a68,a68c);
    a69 = pressed('f',100,a69,a69c);
    a70 = pressed('d',0,a70,a70c);
    a71 = pressed('f',100,a71,a71c);
    a72 = pressed('j',200,a72,a72c);
    a73 = pressed('k',300,a73,a73c);
    a74 = pressed('d',0,a74,a74c);
    a75 = pressed('k',300,a75,a75c);
    a76 = pressed('j',200,a76,a76c);
    a77 = pressed('f',100,a77,a77c);
    a78 = pressed('k',300,a78,a78c);
    a79 = pressed('d',0,a79,a79c);
    a80 = pressed('j',200,a80,a80c);
    a81 = pressed('f',100,a81,a81c);
    a82 = pressed('k',300,a82,a82c);
    a83 = pressed('d',0,a83,a83c);
    a84 = pressed('j',200,a84,a84c);
    a85 = pressed('f',100,a85,a85c);
    a86 = pressed('d',0,a86,a86c);
    a87 = pressed('k',300,a87,a87c);
    a88 = pressed('f',100,a88,a88c);
    a89 = pressed('j',200,a89,a89c);
    a90 = pressed('k',300,a90,a90c);
    a91 = pressed('f',100,a91,a91c);
    a92 = pressed('d',0,a92,a92c);
    a93 = pressed('f',100,a93,a93c);
    a94 = pressed('d',0,a94,a94c);
    a95 = pressed('j',200,a95,a95c);
    a96 = pressed('k',300,a96,a96c);
    a97 = pressed('f',100,a97,a97c);
    a98 = stpressed(0,0,a98,3,a98c,1,2);
    a99 = stpressed(3,300,a99,0,a99c,1,2);
    a100 = pressed('f',100,a100,a100c);
    a101 = pressed('k',300,a101,a101c);
    a102 = pressed('f',100,a102,a102c);
    a103 = pressed('j',200,a103,a103c);
    a104 = pressed('k',300,a104,a104c);
    a105 = pressed('d',0,a105,a105c);
    a106 = pressed('f',100,a106,a106c);
    a107 = pressed('k',300,a107,a107c);
    a108 = stpressed(3,300,a108,0,a108c,1,2);
    a109 = stpressed(0,0,a109,3,a109c,1,2);
    a110 = pressed('f',100,a110,a110c);
    a111 = pressed('d',0,a111,a111c);
    a112 = pressed('j',200,a112,a112c);
    a113 = pressed('d',0,a113,a113c);
    a114 = pressed('f',100,a114,a114c);
    a115 = pressed('k',300,a115,a115c);
    a116 = pressed('j',200,a116,a116c);
    a117 = pressed('f',100,a117,a117c);
    a118 = pressed('d',0,a118,a118c);
    a119 = stpressed(3,300,a119,0,a119c,1,2);
    a120 = stpressed(0,0,a120,3,a120c,1,2);
    a121 = pressed('j',200,a121,a121c);
    a122 = pressed('f',100,a122,a122c);
    a123 = stpressed(3,300,a123,0,a123c,1,2);
    a124 = stpressed(0,0,a124,3,a124c,1,2);
    a125 = pressed('f',100,a125,a125c);
    a126 = pressed('j',200,a126,a126c);
    a127 = stpressed(3,300,a127,0,a127c,1,2);
    a128 = stpressed(0,0,a128,3,a128c,1,2);
    a129 = stpressed(1,100,a129,2,a129c,3,0);
    a130 = stpressed(2,200,a130,1,a130c,3,0);
    a131 = stpressed(3,300,a131,0,a131c,1,2);
    a132 = stpressed(0,0,a132,3,a132c,1,2);
    a133 = stpressed(1,100,a133,2,a133c,3,0);
    a134 = stpressed(2,200,a134,1,a134c,3,0);
    a135 = stpressed(3,300,a135,0,a135c,1,2);
    a136 = stpressed(0,0,a136,3,a136c,1,2);
    a137 = stpressed(1,100,a137,2,a137c,3,0);
    a138 = stpressed(2,200,a138,1,a138c,3,0);
    a139 = pressed('k',300,a139,a139c);
    a140 = pressed('j',200,a140,a140c);
    a141 = pressed('f',100,a141,a141c);
    a142 = pressed('d',0,a142,a142c);
    a143 = pressed('k',300,a143,a143c);
    a144 = pressed('j',200,a144,a144c);
    a145 = pressed('f',100,a145,a145c);
    a146 = pressed('d',0,a146,a146c);
    a147 = pressed('f',100,a147,a147c);
    a148 = pressed('k',300,a148,a148c);
    a149 = pressed('d',0,a149,a149c);
    a150 = pressed('j',200,a150,a150c);
    a151 = pressed('f',100,a151,a151c);
    a152 = pressed('j',200,a152,a152c);
    a153 = pressed('d',0,a153,a153c);
    a154 = pressed('k',300,a154,a154c);
    a155 = pressed('j',200,a155,a155c);
    a156 = pressed('d',0,a156,a156c);
    a157 = pressed('f',100,a157,a157c);
    a158 = pressed('k',300,a158,a158c);
    a159 = pressed('f',100,a159,a159c);
    a160 = pressed('j',200,a160,a160c);
    a161 = pressed('d',0,a161,a161c);
    a162 = pressed('k',300,a162,a162c);
    a163 = pressed('f',100,a163,a163c);
    a164 = pressed('j',200,a164,a164c);
    a165 = pressed('d',0,a165,a165c);
    a166 = pressed('f',100,a166,a166c);
    a167 = pressed('k',300,a167,a167c);
    a168 = pressed('f',100,a168,a168c);
    a169 = pressed('j',200,a169,a169c);
    a170 = pressed('f',100,a170,a170c);
    a171 = pressed('d',0,a171,a171c);
    a172 = pressed('k',300,a172,a172c);
    a173 = pressed('f',100,a173,a173c);
    a174 = pressed('j',200,a174,a174c);
    a175 = pressed('d',0,a175,a175c);
    a176 = pressed('k',300,a176,a176c);
    a177 = pressed('j',200,a177,a177c);
    a178 = pressed('f',100,a178,a178c);
    a179 = pressed('d',0,a179,a179c);
    a180 = pressed('j',200,a180,a180c);
    a181 = pressed('f',100,a181,a181c);
    a182 = pressed('k',300,a182,a182c);
    a183 = pressed('d',0,a183,a183c);
    a184 = pressed('j',200,a184,a184c);
    a185 = pressed('k',300,a185,a185c);
    a186 = pressed('f',100,a186,a186c);
    a187 = pressed('d',0,a187,a187c);
    a188 = pressed('f',100,a188,a188c);
    a189 = pressed('j',200,a189,a189c);
    a190 = pressed('k',300,a190,a190c);
    a191 = pressed('f',100,a191,a191c);
    a192 = pressed('j',200,a192,a192c);
    a193 = pressed('f',100,a193,a193c);
    a194 = pressed('k',300,a194,a194c);
    a195 = pressed('d',0,a195,a195c);
    a196 = pressed('j',200,a196,a196c);
    a197 = pressed('f',100,a197,a197c);
    a198 = pressed('d',0,a198,a198c);
    a199 = pressed('j',200,a199,a199c);
    a200 = pressed('k',300,a200,a200c);
    a201 = pressed('d',0,a201,a201c);
    a202 = pressed('j',200,a202,a202c);
    a203 = pressed('k',300,a203,a203c);
    a204 = pressed('j',200,a204,a204c);
    a205 = pressed('d',0,a205,a205c);
    a206 = pressed('f',100,a206,a206c);
    a207 = pressed('k',300,a207,a207c);
    a208 = pressed('j',200,a208,a208c);
    a209 = pressed('d',0,a209,a209c);
    a210 = pressed('f',100,a210,a210c);
    a211 = pressed('k',300,a211,a211c);
    a212 = pressed('j',200,a212,a212c);
    a213 = pressed('d',0,a213,a213c);
    a214 = pressed('f',100,a214,a214c);
    a215 = pressed('k',300,a215,a215c);
    a216 = pressed('j',200,a216,a216c);
    a217 = pressed('d',0,a217,a217c);
    a218 = pressed('f',100,a218,a218c);
    a219 = pressed('k',300,a219,a219c);
    a220 = pressed('f',100,a220,a220c);
    a221 = pressed('d',0,a221,a221c);
    a222 = pressed('j',200,a222,a222c);
    a223 = pressed('f',100,a223,a223c);
    a224 = pressed('k',300,a224,a224c);
    a225 = pressed('d',0,a225,a225c);
    a226 = pressed('f',100,a226,a226c);
    a227 = pressed('j',200,a227,a227c);
    a228 = pressed('k',300,a228,a228c);
    a229 = pressed('j',200,a229,a229c);
    a230 = pressed('f',100,a230,a230c);
    a231 = pressed('d',0,a231,a231c);
    a232 = pressed('k',300,a232,a232c);
    a233 = pressed('j',200,a233,a233c);
    a234 = pressed('f',100,a234,a234c);
    a235 = pressed('d',0,a235,a235c);
    a236 = pressed('k',300,a236,a236c);
    a237 = pressed('f',100,a237,a237c);
    a238 = pressed('j',200,a238,a238c);
    a239 = pressed('k',300,a239,a239c);
    a240 = pressed('d',0,a240,a240c);
    a241 = pressed('f',100,a241,a241c);
    a242 = pressed('j',200,a242,a242c);
    a243 = pressed('d',0,a243,a243c);
    a244 = pressed('k',300,a244,a244c);
    a245 = pressed('j',200,a245,a245c);
    a246 = pressed('k',300,a246,a246c);
    a247 = pressed('f',100,a247,a247c);
    a248 = pressed('d',0,a248,a248c);
    a249 = pressed('j',200,a249,a249c);
    a250 = pressed('d',0,a250,a250c);
    a251 = pressed('k',300,a251,a251c);
    a252 = pressed('f',100,a252,a252c);
    a253 = pressed('d',0,a253,a253c);
    a254 = pressed('j',200,a254,a254c);
    a255 = pressed('f',100,a255,a255c);
    a256 = pressed('k',300,a256,a256c);
    a257 = pressed('d',0,a257,a257c);
    a258 = pressed('j',200,a258,a258c);
    a259 = pressed('f',100,a259,a259c);
    a260 = pressed('k',300,a260,a260c);
    a261 = pressed('d',0,a261,a261c);
    a262 = pressed('f',100,a262,a262c);
    a263 = pressed('k',300,a263,a263c);
    a264 = pressed('d',0,a264,a264c);
    a265 = pressed('j',200,a265,a265c);
    a266 = pressed('k',300,a266,a266c);
    a267 = pressed('k',300,a267,a267c);
    a268 = pressed('k',300,a268,a268c);
    a269 = pressed('k',300,a269,a269c);
    a270 = pressed('j',200,a270,a270c);
    a271 = pressed('f',100,a271,a271c);
    a272 = pressed('d',0,a272,a272c);
    a273 = pressed('k',300,a273,a273c);
    a274 = pressed('j',200,a274,a274c);
    a275 = pressed('f',100,a275,a275c);
    a276 = pressed('d',0,a276,a276c);
    a277 = pressed('k',300,a277,a277c);
    a278 = pressed('f',100,a278,a278c);
    a279 = pressed('j',200,a279,a279c);
    a280 = pressed('f',100,a280,a280c);
    a281 = pressed('d',0,a281,a281c);
    a282 = pressed('k',300,a282,a282c);
    a283 = pressed('j',200,a283,a283c);
    a284 = pressed('f',100,a284,a284c);
    a285 = pressed('d',0,a285,a285c);
    a286 = pressed('j',200,a286,a286c);
    a287 = pressed('f',100,a287,a287c);
    a288 = pressed('k',300,a288,a288c);
    a289 = pressed('d',0,a289,a289c);
    a290 = pressed('j',200,a290,a290c);
    a291 = pressed('f',100,a291,a291c);
    a292 = pressed('k',300,a292,a292c);
    a293 = pressed('d',0,a293,a293c);
    a294 = pressed('j',200,a294,a294c);
    a295 = pressed('f',100,a295,a295c);
    a296 = pressed('d',0,a296,a296c);
    a297 = pressed('k',300,a297,a297c);
    a298 = pressed('f',100,a298,a298c);
    a299 = pressed('d',0,a299,a299c);
    a300 = pressed('j',200,a300,a300c);
    a301 = pressed('f',100,a301,a301c);
    a302 = pressed('k',300,a302,a302c);
    a303 = pressed('j',200,a303,a303c);
    a304 = pressed('d',0,a304,a304c);
    a305 = pressed('f',100,a305,a305c);
    a306 = pressed('k',300,a306,a306c);
    a307 = pressed('j',200,a307,a307c);
    a308 = pressed('d',0,a308,a308c);
    a309 = pressed('k',300,a309,a309c);
    a310 = pressed('f',100,a310,a310c);
    a311 = pressed('j',200,a311,a311c);
    a312 = pressed('d',0,a312,a312c);
    a313 = pressed('f',100,a313,a313c);
    a314 = pressed('k',300,a314,a314c);
    a315 = pressed('f',100,a315,a315c);
    a316 = pressed('j',200,a316,a316c);
    a317 = pressed('k',300,a317,a317c);
    a318 = pressed('d',0,a318,a318c);
    a319 = pressed('k',300,a319,a319c);
    a320 = pressed('j',200,a320,a320c);
    a321 = pressed('k',300,a321,a321c);
    a322 = pressed('j',200,a322,a322c);
    a323 = pressed('f',100,a323,a323);
    a324 = pressed('d',0,a324,a324c);
    a325 = pressed('f',100,a325,a325c);
    a326 = pressed('j',200,a326,a326c);
    a327 = pressed('k',300,a327,a327c);
    a328 = pressed('j',200,a328,a328c);
    a329 = pressed('f',100,a329,a329c);
    a330 = pressed('d',0,a330,a330c);
    a331 = pressed('f',100,a331,a331c);
    a332 = pressed('j',200,a332,a332c);
    a333 = pressed('k',300,a333,a333c);
    a334 = pressed('j',200,a334,a334c);
    a335 = pressed('f',100,a335,a335c);
    a336 = pressed('d',0,a336,a336c);
    a337 = pressed('f',100,a337,a337c);
    a338 = pressed('j',200,a338,a338c);
    a339 = pressed('k',300,a339,a339c);
    a340 = pressed('j',200,a340,a340c);
    a341 = pressed('f',100,a341,a341c);
    a342 = pressed('d',0,a342,a342c);
    a343 = pressed('f',100,a343,a343c);
    a344 = pressed('j',200,a344,a344c);
    a345 = pressed('k',300,a345,a345c);
    a346 = pressed('j',200,a346,a346c);
    a347 = pressed('f',100,a347,a347c);
    a348 = pressed('d',0,a348,a348c);
    a349 = pressed('f',100,a349,a349c);
    a350 = pressed('j',200,a350,a350c);
    a351 = pressed('k',300,a351,a351c);
    a352 = pressed('j',200,a352,a352c);
    a353 = pressed('f',100,a353,a353c);
    a354 = pressed('d',0,a354,a354c);
    a355 = pressed('f',100,a355,a355c);
    a356 = pressed('j',200,a356,a356c);
    a357 = pressed('k',300,a357,a357c);
    a358 = pressed('j',200,a358,a358c);
    a359 = pressed('f',100,a359,a359c);
    a360 = pressed('d',0,a360,a360c);
    a361 = pressed('k',300,a361,a361c);
    a362 = pressed('k',300,a362,a362c);
    a363 = pressed('k',300,a363,a363c);
    a364 = pressed('k',300,a364,a364c);
  }
  stroke(0);
  strokeWeight(10);
  line(0,650,400,650);
  line(400,0,400,700);
  line(0,700,400,700);
  strokeWeight(1);
  line(100,0,100,800);
  line(200,0,200,800);
  line(300,0,300,800);
  fill(255,50);    
  stroke(200,0);
  rect(0,0,width,height);
  fill(0);
  textSize(24);
  //text("speed: " + sp,410,600);
  text("score: " + sc,410,350);
  if(start[0] === false)
  {
    //fill(0);
    //rect(410,60,180,60);
    //fill(255);
    //textSize(24);
    //text("speed up",450,100);
    fill(0);
    text("press p to start",110,350);
    if(sp > 1)
    {
      //fill(0);
      //rect(410,360,180,60);
      //fill(255);
      //text("speed down",430,400);
    }
  }
  if(keyIsDown(80))
  {
    start[0] = true;
  }
  if(keyIsDown(68))
  {
    press[0] = true;
  }
  else
  {
    press[0] = false;
  }
  if(keyIsDown(70))
  {
    press[1] = true;
  }
  else
  {
    press[1] = false;
  }
  if(keyIsDown(74))
  {
    press[2] = true;
  }
  else
  {
    press[2] = false;
  }
  if(keyIsDown(75))
  {
    press[3] = true;
  }
  else
  {
    press[3] = false;
  }
}
function keyTyped()
{
  if (key === 'p'&&start[0] === false)
  {
    sec = 0;
    song = createAudio('freedomdive.mp3');
    song.autoplay(true);
    song.volume(0.01);
  }
}
//function keyReleased()
//{
  //if(key == 'd')
  //{
    //press[0] = false;
  //}
  //if(key == 'f')
  //{
    //press[1] = false;
  //}
  //if(key == 'j')
  //{
    //press[2] = false;
  //}
  //if(key == 'k')
  //{
    //press[3] = false;
  //}
//}
function pressed(x,y,z,w)
{
  wei = (700 - (sp - (-w % sp)));
  weia = wei + (sp -(wei % sp)) + (sp - (-w % sp));
  z += sp;
  if(keyIsPressed === true&&z > 600&&z < 750)
  {
    if(key === x)
    {
      z = 900;
      sc = sc + 1000 + 5*com;
      com += 1;
    }
  }
  if(z === weia)
  {
    com += 1;
  }
  image(s,y,z,100,50);
  return z;
}
function stpressed(b,c,d,e,f,g,h)
{
  wei = (700 - (sp - (-f % sp)));
  weia = wei + (sp -(wei % sp)) + (sp - (-f % sp));
  d += sp;
  if(keyIsPressed === true&&d > 600&&d < 750)
  {
    if(press[b]&&press[e]&&press[g] === false&&press[h] === false)
    {       
      d = 900;
      sc = sc + 1000 + 5*com;
      com += 1;
    }
  }
  if(d === weia)
  {
    com += 1;
  }
  image(s,c,d,100,50);
  return d;
}
//function mouseClicked()
//{
  //if(start[0] === false&&sp > 1)
  //{
    //if(mouseX >= 410&&mouseX <= 590&&
       //mouseY >= 360&&mouseY <= 420&&sp >= 0)
       //{
         //sp -= 1;
       //}
  //}
   //if(mouseX >= 410&&mouseX <= 590&&
      //mouseY >= 60&&mouseY <= 120)
      //{
        //sp += 1;
      //}
//}
//function longpressed(b,c,d)
//{
  //c += sp;
  //fill(0);
  //rect(b,c,100,d);
  //if(c > 660)
  //{
    //c = 800;
  //}
  //if(keyIsPressed !== true&&
     //press[0] !== true&&
     //c + d > 700)
  //{
    //c = 800;
  //}
  //return c;
//}